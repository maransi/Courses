﻿<h1>Gerador de Tables e Views do banco de dados MySql para uso com o SimpleORM.</h1>

<p>Gerador de tables e views junto ao SimpleORM https://github.com/bittencourtthulio/SimpleORM </p>
<p>O SimpleORM tem o Objetivo de facilitar suas implementações de CRUD, agilizando mais de 80% do seu processo de desenvolvimento de software.</p>
</br>
<p>Fico a disposição para auxiliar caso possuir dúvidas de como utiliza-lo.</p>
</br>
<p>Douglas Colombo</p>
<p>(51) 99550-2636</p>


