﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Renci.SshNet;
using System.IO;
using System.Configuration;
using System.Collections.Specialized;


namespace JBLibraryDll
{
    [ClassInterface(ClassInterfaceType.None), Guid("DD0383F1-BD5C-4350-A646-CA2A8B69FBEE")]
    public class ClasseJBLibraryDll : InterfaceJb
    {
        private static SftpClient sftp;
        List<string> LISTA = new List<string>();
        //listas os arquivos da pasta retorno do FTP
        public string ListarArquivos(int Tipo)
        {
            string ret = string.Empty;
            try
            {
                conecta();
                if (Tipo == 1)
                {
                    LISTA = ListaArquivosRetorno();                    
                }
                else
                {
                    LISTA = ListaArquivosRemessa();                    
                }
                
                for (int i = 0; i < LISTA.Count; i++)
                {
                    ret += Path.GetFileName(LISTA[i]) + "\r\n"; //";";
                }

                if (LISTA.Count == 0)
                {
                    ret = "1";
                }
            }
            catch (Exception ex)
            {

                ret = ex.Message;
            }
            Dispose();
            
            return ret;
        }

        public string EnviaArquivoRemessa(string Arquivo)
        {
            string ret = string.Empty;
            try
            {
                conecta();
                sftp.ChangeDirectory("/negativacao/remessa");
                EnviarRemessa(Arquivo);
                ret = "OK";
            }
            catch (Exception ex)
            {

                ret = ex.Message;
            }
            return ret;
        }

        public string CopiaArquivoRetorno(string arquivo, string diretorio)
        {
            string ret = string.Empty;
            try
            {
                conecta();
                sftp.ChangeDirectory("/negativacao/retorno");
                CopiaRetorno(arquivo,diretorio);
                ret = "OK";
            }
            catch (Exception ex)
            {

                ret = ex.Message;
            }
            return ret;
        }

        public string ApagarArquivo(string arquivo, string diretorio)
        {
            string ret = string.Empty;
            try
            {
                conecta();              

                sftp.ChangeDirectory(diretorio);
                DeleteArquivo(arquivo);
                ret = "OK";
            }
            catch (Exception ex)
            {

                ret = ex.Message;
            }
            return ret;
        }

        public long TamanhoArquivo(string arquivo, string diretorio)
        {
            long ret = 0;
            try
            {
                conecta();

                sftp.ChangeDirectory(diretorio);
                ret = sftp.GetAttributes(arquivo).Size;                
            }
            catch (Exception ex)
            {

                ret = -1;
            }
            return ret;
        }

        void DeleteArquivo(string arquivo)
        {
            try
            {
                sftp.DeleteFile(arquivo);

            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("Erro ao apagar arquivo:{0}", arquivo), ex);
            }
        }




        void conecta()
        {
            try
            {
                /*
                string host = ConfigurationManager.AppSettings.Get("Host"); 
                string usuario = ConfigurationManager.AppSettings.Get("Login"); 
                string senha = ConfigurationManager.AppSettings.Get("Senha");
                int porta = Convert.ToInt32(ConfigurationManager.AppSettings.Get("Porta"));
                */

                sftp = new SftpClient(new PasswordConnectionInfo("ts.bvsnet.com.br", 9022, "jbcred", "Jb(r3dYzqp"));
                //sftp = new SftpClient(new PasswordConnectionInfo(host, porta, usuario, senha));
                sftp.ConnectionInfo.Timeout = TimeSpan.FromSeconds(120);
                sftp.Connect();
            }
            catch (Exception)
            {

                throw;
            }

        }

        List<string> ListaArquivosRetorno()
        {
            try
            {
                var result = (from a in sftp.ListDirectory("/negativacao/retorno")
                              where a.IsRegularFile && Path.GetExtension(a.FullName).ToUpper() == ".RET"
                              select a.FullName).ToList();

                return result;
            }
            catch (Exception ex)
            {
                //throw new Exception("Erro ao listar arquivos pendentes para cópia", ex);
                throw new Exception("100", ex);
            }

        }

        List<string> ListaArquivosRemessa()
        {
            try
            {
                var result = (from a in sftp.ListDirectory("/negativacao/remessa")
                              where a.IsRegularFile && Path.GetExtension(a.FullName).ToUpper() == ".RET"
                              select a.FullName).ToList();

                return result;
            }
            catch (Exception ex)
            {
                //throw new Exception("Erro ao listar arquivos pendentes para cópia", ex);
                throw new Exception("100", ex);
            }

        }

        void CopiaRetorno(string arquivo, string diretorio)
        {
            try
            {
                using (var stream = File.Create(Path.Combine(diretorio, Path.GetFileName(arquivo))))
                {
                    var async = sftp.BeginDownloadFile(arquivo, stream);

                    while (!async.IsCompleted) { }
                    sftp.EndDownloadFile(async);
                }

            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("Erro ao copiar arquivo:{0} para o diretório:{1}", arquivo, diretorio), ex);
            }
        }

        void EnviarRemessa(string arquivo)
        {
            try
            {
                
                using (var uplfileStream = System.IO.File.OpenRead(arquivo))
                {
                    sftp.UploadFile(uplfileStream, Path.GetFileName(arquivo));
                }                    

            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("Erro ao copiar arquivo:{0} para o FTP", arquivo), ex);
            }
        }

        void Dispose()
        {
            sftp.Disconnect();
            sftp.Dispose();
        }
    }
}
