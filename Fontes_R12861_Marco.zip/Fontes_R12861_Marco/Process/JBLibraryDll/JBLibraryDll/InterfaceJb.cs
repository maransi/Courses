﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace JBLibraryDll
{
    [InterfaceType(ComInterfaceType.InterfaceIsDual),Guid("D18A32A4-3AC2-441D-8325-434D510F6008")]
    public interface InterfaceJb
    {
        string ListarArquivos(int Tipo);
        string EnviaArquivoRemessa(string Arquivo);

        string CopiaArquivoRetorno(string arquivo, string diretorio);

        string ApagarArquivo(string arquivo, string diretorio);

        long TamanhoArquivo(string arquivo, string diretorio);


    }
}
